const start = document.getElementById("start");
const quit = document.getElementById("quit");
const quit2 = document.getElementById("quit2");
const restart = document.getElementById("restart");
const mainMenu = document.getElementById("mainMenu");
const game = document.getElementById("game");
const ready = document.getElementById("ready");
const ready2 = document.getElementById("ready2");
const highNoon = document.getElementById("highNoon");
const cowboy1 = document.getElementById("cowboy");
const cowboy2 = document.getElementById("cowboy2");
const death1 = document.getElementById("death");
const death2 = document.getElementById("death2");
const results = document.getElementById("results");
const msCounter = document.getElementById("ms")

let redy = false;
let redy2 = false;
let gameStart = 0;
let highNoonCheck = false;
let deathCheck1 = false;
let deathCheck2 = false;
let ms = 0;

start.onclick = () => {
  document.body.style.backgroundImage = "url(./res/img/ulice2.jpg)";
  mainMenu.style.display = "none";
  game.style.display = "block";
};

quit.onclick = () => {
  window.close();
};
quit2.onclick = () => {
  window.close();
};
restart.onclick = () => {
  const check = setInterval(() => {
    if (highNoon.style.backgroundColor == "green") {
      clearInterval(check);
      const time = setInterval(() => {
        if (!deathCheck1 && !deathCheck2) {
          ms++;
        } else {
          clearInterval(time);
        }
        console.log(ms);
      }, 1);
    }
  }, 1);
  death1.style.display = "none";
  death2.style.display = "none";
  cowboy1.style.display = "block";
  cowboy2.style.display = "block";
  redy = false;
  redy2 = false;
  gameStart = 0;
  highNoonCheck = false;
  deathCheck1 = false;
  deathCheck2 = false;
  ready.style.display = "block";
  ready2.style.display = "block";
  highNoon.style.display = "none";
  results.style.display = "none";
  ready.innerHTML = `UNREADY`;
  ready2.innerHTML = `UNREADY`;
  highNoon.style.backgroundColor = "red";
  ms = 0;
};

addEventListener("keypress", check);

function check(e) {
  var x = e.keyCode;
  switch (x) {
    case 115:
      if (game.style.display == "block") {
        ready.innerHTML = `READY`;
        redy = true;
        if (highNoonCheck && redy && redy2 && deathCheck2 != true) {
          cowboy2.style.display = "none";
          death2.style.display = "block";
          deathCheck1 = true;
          results.style.display = "block";
          msCounter.innerHTML = `${ms} ms`
        }
        if (redy == true && redy2 == true) {
          ready.style.display = "none";
          ready2.style.display = "none";
          highNoon.style.display = "block";
          if (gameStart == 0) {
            gameStart++;
            let x = Math.floor(Math.random() * 10000) + 2000;
            setTimeout(() => {
              highNoon.style.backgroundColor = "green";
              highNoonCheck = true;
            }, x);
          }
        }
      }
      break;
    case 107:
      if (game.style.display == "block") {
        ready2.innerHTML = `READY`;
        redy2 = true;
        if (
          highNoonCheck == true &&
          redy == true &&
          redy2 == true &&
          deathCheck1 != true
        ) {
          cowboy1.style.display = "none";
          death1.style.display = "block";
          deathCheck2 = true;
          results.style.display = "block";
          msCounter.innerHTML = `${ms} ms`
        }
        if (redy == true && redy2 == true) {
          ready.style.display = "none";
          ready2.style.display = "none";
          highNoon.style.display = "block";
          if (gameStart == 0) {
            gameStart++;
            let x = Math.floor(Math.random() * 10000) + 2000;
            setTimeout(() => {
              highNoon.style.backgroundColor = "green";
              highNoonCheck = true;
            }, x);
          }
        }
      }
      break;
  }
}

onload = () => {
  const check = setInterval(() => {
    if (highNoon.style.backgroundColor == "green") {
      clearInterval(check);
      const time = setInterval(() => {
        if (!deathCheck1 && !deathCheck2) {
          ms++;
        } else {
          clearInterval(time);
        }
      }, 1);
    }
  }, 1);
};
